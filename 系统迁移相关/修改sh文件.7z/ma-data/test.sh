#!/bin/bash

. ~/.profile 

# script path /oracle/ma-data/
# 数仓
dwip=82.211.15.106  
# 管会
maip=82.211.15.106
 # get the useful date values

echo $1

