
 
 


sqlldr src_layer/oracle@ICBCAMCDW control=/dw-data/AICS/control/AICS_REPAY_CONFIRM.ctl log=repay_confirm.log bad=repay_confirm.bad



echo "complate"
